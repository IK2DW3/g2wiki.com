QNAP recommends Ubuntu 16.04 for Qfinder Pro.

1. Install the dependent package:

        $ sudo apt-get update
        $ sudo apt-get install nfs-common

2. Install the Qfinder package and execute:

        $ sudo dpkg -i QNAPQfinderProUbuntux86-x.x.x.MMDD.deb

3. Launch Qfinder Pro:

        Launch from the Dash menu:
        a.  Press the Windows key.
        b. Type "QfinderPro" in the search bar of the Dash menu.
        c. Click the Qfinder Pro icon.

        Launch from desktop:
        a. Press CRTL + Windows key + D to open a new desktop window.
        b. Double-click the Qfinder Pro icon.

Important: To avoid errors, do not launch more than one version of Qfinder at the same time.
